"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Wand2, Upload, X, Download, RefreshCw, Sparkles, Loader2, Image as ImageIcon, History, Lightbulb, CheckCircle2, AlertCircle, Copy } from "lucide-react";
import { STYLES, ASPECTS, SUGGESTIONS } from "@/lib/data";
import { downloadImage } from "@/components/ImageCard";
import Link from "next/link";

function Workspace() {
  const params = useSearchParams();
  const [prompt, setPrompt] = useState(params.get("prompt") || "");
  const [style, setStyle] = useState(params.get("style") || "photorealistic");
  const [aspect, setAspect] = useState(params.get("aspect") || "1:1");
  const [count, setCount] = useState(1);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState("");
  const [results, setResults] = useState<any>(null);
  const [error, setError] = useState("");
  const [reference, setReference] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [copied, setCopied] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadHistory = () => fetch("/api/generations?mine=1").then(r => r.json()).then(d => setHistory(d.generations || [])).catch(() => {});
  useEffect(() => { loadHistory(); }, []);
  useEffect(() => { if (params.get("prompt")) setPrompt(params.get("prompt")!); if (params.get("style")) setStyle(params.get("style")!); if (params.get("aspect")) setAspect(params.get("aspect")!); }, [params]);

  const onFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setError("Please upload an image file (PNG, JPG, WEBP)."); return; }
    if (file.size > 5 * 1024 * 1024) { setError("Reference image must be under 5MB."); return; }
    const reader = new FileReader();
    reader.onload = () => setReference(reader.result as string);
    reader.readAsDataURL(file);
  };

  const generate = async (overridePrompt?: string) => {
    const p = (overridePrompt || prompt).trim();
    if (!p) { setError("Please describe the image you want to create."); return; }
    setLoading(true); setError(""); setResults(null);
    setProgress("Analyzing your prompt…");
    const steps = ["Analyzing your prompt…", "Enhancing with style details…", "Dreaming up pixels with FLUX AI…", "Rendering high-resolution details…", "Final touches…"];
    let si = 0; const timer = setInterval(() => { si = Math.min(si + 1, steps.length - 1); setProgress(steps[si]); }, 6000);
    try {
      const res = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt: p, style, aspectRatio: aspect, count, referenceImage: reference }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Generation failed. Please try again.");
      if (!data.images?.length) throw new Error("The AI did not return any images. Please try again — we never fake a result.");
      setResults(data); loadHistory();
    } catch (e: any) { setError(e.message || "Generation failed. Please try again."); }
    finally { clearInterval(timer); setLoading(false); setProgress(""); }
  };

  const aspectDef = ASPECTS.find(a => a.id === aspect) || ASPECTS[0];

  return (
    <div className="pt-16 min-h-screen">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold tracking-widest text-fuchsia-400 uppercase flex items-center gap-1.5"><Wand2 className="w-4 h-4" /> AI Studio</p>
            <h1 className="text-3xl sm:text-4xl font-black mt-1" style={{fontFamily:"Space Grotesk, sans-serif"}}>Image Generator</h1>
            <p className="text-zinc-400 text-sm mt-1">Describe it. Style it. Generate it — in seconds.</p>
          </div>
          <Link href="/gallery" className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm font-medium hover:bg-white/10"><History className="w-4 h-4" /> My Gallery</Link>
        </div>

        <div className="mt-6 grid lg:grid-cols-[420px_1fr] gap-5 items-start">
          {/* CONTROLS */}
          <div className="glass rounded-[28px] p-5 sm:p-6 space-y-6 lg:sticky lg:top-24">
            <div>
              <label className="text-sm font-bold flex items-center justify-between">Your prompt <span className={`text-xs font-normal ${prompt.length > 1800 ? "text-rose-400" : "text-zinc-500"}`}>{prompt.length}/2000</span></label>
              <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe the image you want to create... e.g. A majestic lion wearing a golden crown in a royal palace, cinematic lighting" rows={4}
                className="mt-2 w-full rounded-2xl bg-black/30 border border-white/10 focus:border-violet-400/60 outline-none p-4 text-sm leading-relaxed placeholder:text-zinc-600 resize-none" />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {SUGGESTIONS.slice(0, 3).map(s => <button key={s} onClick={() => setPrompt(s)} className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:border-violet-400/40 transition truncate max-w-[200px]">{s}</button>)}
              </div>
              <button onClick={() => setPrompt(SUGGESTIONS[Math.floor(Math.random() * SUGGESTIONS.length)])} className="mt-2 text-xs text-violet-300 hover:text-violet-200 inline-flex items-center gap-1"><Lightbulb className="w-3.5 h-3.5" /> Surprise me — random idea</button>
            </div>

            <div>
              <label className="text-sm font-bold">Reference image <span className="text-zinc-500 font-normal">(optional, image-to-image)</span></label>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => onFile(e.target.files?.[0])} />
              {reference ? (
                <div className="mt-2 relative rounded-2xl overflow-hidden border border-white/10">
                  <img src={reference} className="w-full h-36 object-cover" alt="reference" />
                  <button onClick={() => setReference(null)} className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600"><X className="w-4 h-4" /></button>
                  <span className="absolute bottom-2 left-2 text-[11px] px-2 py-1 rounded-full bg-black/70">Reference attached ✓</span>
                </div>
              ) : (
                <div onClick={() => fileRef.current?.click()} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); onFile(e.dataTransfer.files?.[0]); }}
                  className="mt-2 border-2 border-dashed border-white/15 hover:border-violet-400/50 rounded-2xl p-5 text-center cursor-pointer transition bg-black/20">
                  <Upload className="w-6 h-6 mx-auto text-zinc-500" />
                  <p className="text-sm font-medium mt-2">Upload reference image</p>
                  <p className="text-xs text-zinc-500 mt-0.5">Drag & drop or click · PNG/JPG up to 5MB</p>
                </div>
              )}
            </div>

            <div>
              <label className="text-sm font-bold">Style</label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {STYLES.map(s => (
                  <button key={s.id} onClick={() => setStyle(s.id)} className={`rounded-2xl border p-3 text-left transition ${style === s.id ? "border-violet-400 bg-violet-500/15" : "border-white/10 bg-white/[0.03] hover:border-white/25"}`}>
                    <span className="text-lg">{s.emoji}</span><p className="text-xs font-bold mt-1 leading-tight">{s.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-bold">Aspect ratio</label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {ASPECTS.map(a => (
                  <button key={a.id} onClick={() => setAspect(a.id)} className={`rounded-2xl border p-3 flex flex-col items-center gap-1.5 transition ${aspect === a.id ? "border-fuchsia-400 bg-fuchsia-500/10" : "border-white/10 bg-white/[0.03] hover:border-white/25"}`}>
                    <span className={`bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-sm ${a.id === "1:1" ? "w-6 h-6" : a.id === "16:9" ? "w-9 h-5" : a.id === "9:16" ? "w-5 h-9" : a.id === "4:5" ? "w-6 h-7" : a.id === "3:2" ? "w-8 h-5" : "w-5 h-8"}`} />
                    <span className="text-xs font-bold">{a.label}</span><span className="text-[10px] text-zinc-500">{a.desc} · {a.w}×{a.h}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-bold">Number of images</label>
              <div className="mt-2 grid grid-cols-4 gap-2">
                {[1, 2, 3, 4].map(n => <button key={n} onClick={() => setCount(n)} className={`py-2.5 rounded-xl border text-sm font-bold transition ${count === n ? "bg-gradient-to-r from-violet-600 to-fuchsia-500 border-transparent" : "border-white/10 bg-white/[0.03] hover:border-white/25"}`}>{n}</button>)}
              </div>
              <p className="text-[11px] text-zinc-500 mt-1.5">High-resolution · {aspectDef.w}×{aspectDef.h}px per image</p>
            </div>

            <button onClick={() => generate()} disabled={loading} className="w-full py-4 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 font-black text-base shadow-lg shadow-fuchsia-500/30 hover:scale-[1.01] active:scale-95 transition disabled:opacity-60 disabled:scale-100 flex items-center justify-center gap-2">
              {loading ? <><Loader2 className="w-5 h-5 animate-spin" /> Generating…</> : <><Sparkles className="w-5 h-5" /> Generate Image</>}
            </button>
            {error && <div className="flex gap-2 p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-sm text-rose-200"><AlertCircle className="w-5 h-5 shrink-0" /><span>{error}</span></div>}
            <p className="text-[11px] text-zinc-600 text-center leading-relaxed">Safe & moderated · Results are real AI generations — if generation fails, we tell you honestly.</p>
          </div>

          {/* PREVIEW */}
          <div className="space-y-5">
            <div className="glass rounded-[28px] p-5 sm:p-6 min-h-[420px]">
              <div className="flex items-center justify-between">
                <h2 className="font-bold flex items-center gap-2"><ImageIcon className="w-5 h-5 text-violet-400" /> Preview</h2>
                {results && <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 inline-flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> {results.model}</span>}
              </div>

              {loading ? (
                <div className="mt-6">
                  <div className={`grid gap-3 ${count > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                    {Array.from({ length: count }).map((_, i) => (
                      <div key={i} className="shimmer rounded-3xl aspect-square grid place-items-center">
                        <div className="text-center px-4"><Loader2 className="w-8 h-8 animate-spin mx-auto text-violet-400" /><p className="text-sm font-medium mt-3">{progress}</p><p className="text-xs text-zinc-500 mt-1">This usually takes 10–40 seconds…</p></div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-full transition-all duration-1000" style={{ width: "65%" }} /></div>
                </div>
              ) : results ? (
                <div className="mt-5">
                  <div className={`grid gap-3 ${results.images.length > 1 ? "sm:grid-cols-2" : "grid-cols-1"}`}>
                    {results.images.map((src: string, i: number) => (
                      <div key={i} className="group relative rounded-3xl overflow-hidden bg-zinc-900 animate-fadeUp">
                        <img src={src} alt={`Generated ${i + 1}`} className="w-full object-cover max-h-[520px]" />
                        <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/80 to-transparent flex gap-2 opacity-0 group-hover:opacity-100 transition">
                          <button onClick={() => downloadImage(src)} className="flex-1 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 text-xs font-bold inline-flex items-center justify-center gap-1.5"><Download className="w-3.5 h-3.5" /> Download</button>
                          <a href={src} target="_blank" rel="noreferrer" className="px-3 py-2 rounded-xl bg-white/15 text-xs font-bold">Open</a>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 p-4 rounded-2xl bg-black/25 border border-white/10">
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-wide">Enhanced prompt</p>
                    <p className="text-sm text-zinc-300 mt-1 leading-relaxed">{results.enhancedPrompt}</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button onClick={() => generate()} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold"><RefreshCw className="w-3.5 h-3.5" /> Regenerate</button>
                      <button onClick={() => { navigator.clipboard.writeText(results.enhancedPrompt); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold"><Copy className="w-3.5 h-3.5" /> {copied ? "Copied!" : "Copy prompt"}</button>
                      <Link href="/gallery" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 text-xs font-bold">View in Gallery</Link>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="mt-6 border-2 border-dashed border-white/10 rounded-3xl py-16 px-6 text-center">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-br from-violet-600/30 to-fuchsia-500/30 grid place-items-center animate-float"><Sparkles className="w-8 h-8 text-fuchsia-300" /></div>
                  <p className="font-bold text-lg mt-4">Your masterpiece will appear here</p>
                  <p className="text-sm text-zinc-500 mt-1 max-w-sm mx-auto">Enter a prompt on the left and hit Generate. Try: “A majestic lion wearing a golden crown…”</p>
                  <div className="mt-5 flex flex-wrap justify-center gap-2">{SUGGESTIONS.slice(0, 3).map(s => <button key={s} onClick={() => { setPrompt(s); }} className="text-xs px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-zinc-400 hover:text-white transition max-w-[240px] truncate">{s}</button>)}</div>
                </div>
              )}
            </div>

            {history.length > 0 && (
              <div className="glass rounded-[28px] p-5 sm:p-6">
                <div className="flex items-center justify-between"><h3 className="font-bold flex items-center gap-2"><History className="w-4 h-4 text-violet-400" /> Recent generations</h3><Link href="/gallery" className="text-xs font-semibold text-violet-300 hover:text-violet-200">View all →</Link></div>
                <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {history.slice(0, 4).map((h: any) => (
                    <button key={h.id} onClick={() => { setPrompt(h.prompt); setStyle(h.style); setAspect(h.aspectRatio); if (h.images?.[0]) setResults({ images: h.images, enhancedPrompt: h.enhancedPrompt || h.prompt, model: h.model || "FLUX" }); }} className="group relative rounded-2xl overflow-hidden aspect-square bg-zinc-900 text-left">
                      {h.images?.[0] ? <img src={h.images[0]} className="w-full h-full object-cover group-hover:scale-105 transition" alt={h.prompt} /> : <span className="grid place-items-center w-full h-full text-xs text-zinc-500 p-3 text-center">{h.status}</span>}
                      <span className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/85 to-transparent text-[11px] line-clamp-1">{h.prompt}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function GeneratePage() { return <Suspense fallback={<div className="pt-24 text-center text-zinc-400">Loading studio…</div>}><Workspace /></Suspense>; }
