import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "ImagineAI — Turn Your Imagination Into Reality",
  description: "Generate stunning AI images from text. Photorealistic, cinematic, anime, fantasy, 3D and more — in seconds.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#05050a] text-zinc-100 antialiased min-h-screen">
        <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full bg-violet-600/20 blur-[140px]" />
          <div className="absolute top-[40%] -left-40 w-[500px] h-[500px] rounded-full bg-fuchsia-600/10 blur-[120px]" />
          <div className="absolute bottom-0 -right-40 w-[500px] h-[500px] rounded-full bg-cyan-500/10 blur-[120px]" />
        </div>
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  );
}
