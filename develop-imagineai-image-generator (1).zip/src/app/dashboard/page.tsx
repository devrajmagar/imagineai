"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LayoutDashboard, Images, Heart, Calendar, Wand2, LogOut, Loader2, User, Mail, Sparkles } from "lucide-react";
import ImageCard, { type GenItem } from "@/components/ImageCard";

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [items, setItems] = useState<GenItem[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    Promise.all([fetch("/api/auth/me").then(r => r.json()), fetch("/api/generations?mine=1").then(r => r.json())]).then(([me, gal]) => {
      setUser(me.user); setItems(gal.generations || []); setLoading(false);
      if (!me.user) router.push("/login");
    }).catch(() => setLoading(false));
  }, [router]);
  if (loading) return <div className="pt-32 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-violet-400" /></div>;
  if (!user) return null;
  const totalImages = items.reduce((a, i) => a + (i.images?.length || 0), 0);
  const favs = items.filter(i => i.isFavorite).length;
  const week = items.filter(i => Date.now() - new Date(i.createdAt).getTime() < 7 * 86400000).length;
  const stats = [
    { icon: Images, label: "Total generations", value: items.length, grad: "from-violet-600 to-fuchsia-500" },
    { icon: Sparkles, label: "Images created", value: totalImages, grad: "from-cyan-500 to-blue-600" },
    { icon: Heart, label: "Favorites", value: favs, grad: "from-rose-500 to-pink-600" },
    { icon: Calendar, label: "This week", value: week, grad: "from-amber-500 to-orange-600" },
  ];
  return (
    <div className="pt-16 min-h-screen">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <p className="text-xs font-bold tracking-widest text-violet-400 uppercase flex items-center gap-1.5"><LayoutDashboard className="w-4 h-4" /> Profile dashboard</p>
        <div className="mt-4 glass rounded-[28px] p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center gap-5">
          <span className="w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-600 via-fuchsia-500 to-cyan-400 grid place-items-center text-3xl font-black shadow-xl shadow-fuchsia-500/25">{user.name?.[0]?.toUpperCase()}</span>
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl font-black" style={{fontFamily:"Space Grotesk, sans-serif"}}>Welcome back, {user.name} 👋</h1>
            <p className="text-zinc-400 text-sm mt-1 flex items-center gap-1.5"><Mail className="w-4 h-4" /> {user.email} · Member since {new Date(user.createdAt).toLocaleDateString(undefined, { month: "long", year: "numeric" })}</p>
            <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5"><User className="w-3.5 h-3.5" /> Free Creator plan · Unlimited inspiration · Your gallery syncs across devices</p>
          </div>
          <div className="flex gap-2">
            <Link href="/generate" className="px-5 py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-500 font-bold text-sm inline-flex items-center gap-2"><Wand2 className="w-4 h-4" /> New Image</Link>
            <button onClick={async () => { await fetch("/api/auth/logout", { method: "POST" }); router.push("/"); }} className="px-4 py-3 rounded-2xl bg-white/5 border border-white/10 hover:bg-rose-500/20 text-sm font-semibold inline-flex items-center gap-2"><LogOut className="w-4 h-4" /> Logout</button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {stats.map(s => (
            <div key={s.label} className="glass rounded-3xl p-5">
              <span className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${s.grad} grid place-items-center`}><s.icon className="w-5 h-5" /></span>
              <p className="text-3xl font-black mt-3">{s.value}</p><p className="text-xs text-zinc-500 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 flex items-center justify-between">
          <h2 className="text-xl font-black" style={{fontFamily:"Space Grotesk, sans-serif"}}>Recent creations</h2>
          <Link href="/gallery" className="text-sm font-semibold text-violet-300 hover:text-violet-200">View gallery →</Link>
        </div>
        {items.length === 0 ? (
          <div className="mt-4 glass rounded-[28px] p-10 text-center">
            <Images className="w-10 h-10 mx-auto text-zinc-600" /><p className="font-bold mt-3">No creations yet</p><p className="text-sm text-zinc-500 mt-1">Your generated images will show up here.</p>
            <Link href="/generate" className="mt-4 inline-flex px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 text-sm font-bold">Create your first image</Link>
          </div>
        ) : (
          <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{items.slice(0, 6).map(i => <ImageCard key={i.id} item={i} />)}</div>
        )}
      </div>
    </div>
  );
}
