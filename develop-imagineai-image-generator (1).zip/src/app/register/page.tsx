"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Sparkles, Mail, Lock, User, Loader2, AlertCircle, Check } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [error, setError] = useState(""); const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError("");
    const res = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, password }) });
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Registration failed."); setLoading(false); return; }
    router.push("/generate"); router.refresh();
  };
  return (
    <div className="pt-16 min-h-screen grid place-items-center px-4 py-10">
      <div className="w-full max-w-md glass rounded-[28px] p-7 sm:p-8 animate-fadeUp">
        <span className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-500 grid place-items-center"><Sparkles className="w-6 h-6" /></span>
        <h1 className="text-2xl font-black mt-4" style={{fontFamily:"Space Grotesk, sans-serif"}}>Create your free account</h1>
        <p className="text-sm text-zinc-400 mt-1">Save your gallery, favorites and history. Free forever to start.</p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div><label className="text-sm font-semibold">Name</label><div className="relative mt-1.5"><User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" /><input required value={name} onChange={e => setName(e.target.value)} placeholder="Alex Creator" className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black/30 border border-white/10 outline-none focus:border-violet-400/60 text-sm" /></div></div>
          <div><label className="text-sm font-semibold">Email</label><div className="relative mt-1.5"><Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" /><input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black/30 border border-white/10 outline-none focus:border-violet-400/60 text-sm" /></div></div>
          <div><label className="text-sm font-semibold">Password</label><div className="relative mt-1.5"><Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" /><input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters" className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black/30 border border-white/10 outline-none focus:border-violet-400/60 text-sm" /></div></div>
          {error && <div className="flex gap-2 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-sm text-rose-200"><AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />{error}</div>}
          <button disabled={loading} className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-500 font-bold disabled:opacity-60 flex items-center justify-center gap-2">{loading && <Loader2 className="w-4 h-4 animate-spin" />} Create account & start creating</button>
        </form>
        <div className="mt-5 space-y-1.5 text-xs text-zinc-500">
          {["Unlimited generations", "Personal gallery & history", "Favorites and remixes"].map(t => <p key={t} className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" />{t}</p>)}
        </div>
        <p className="text-sm text-zinc-400 text-center mt-5">Already have an account? <Link href="/login" className="text-violet-300 font-semibold hover:text-violet-200">Log in</Link></p>
      </div>
    </div>
  );
}
