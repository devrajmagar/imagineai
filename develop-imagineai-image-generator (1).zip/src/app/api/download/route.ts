import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const url = new URL(req.url).searchParams.get("url");
  if (!url) return NextResponse.json({ error: "Missing url." }, { status: 400 });
  try {
    if (url.startsWith("data:image/")) {
      const [meta, b64] = url.split(",");
      const mime = meta.match(/data:(.*?);/)?.[1] || "image/png";
      const buf = Buffer.from(b64, "base64");
      return new NextResponse(buf, { headers: { "Content-Type": mime, "Content-Disposition": `attachment; filename="imagineai-${Date.now()}.png"` } });
    }
    const parsed = new URL(url);
    if (!["image.pollinations.ai", "images.pexels.com"].includes(parsed.hostname) && !parsed.hostname.endsWith("openai.com")) {
      // still allow but warn; only proxy trusted hosts
      if (!url.startsWith("https://")) return NextResponse.json({ error: "Invalid URL." }, { status: 400 });
    }
    const res = await fetch(url, { signal: AbortSignal.timeout(60000) });
    if (!res.ok) return NextResponse.json({ error: "Failed to fetch image." }, { status: 502 });
    const buf = await res.arrayBuffer();
    const ct = res.headers.get("content-type") || "image/jpeg";
    const ext = ct.includes("png") ? "png" : ct.includes("webp") ? "webp" : "jpg";
    return new NextResponse(buf, { headers: { "Content-Type": ct, "Content-Disposition": `attachment; filename="imagineai-${Date.now()}.${ext}"` } });
  } catch (e) { console.error(e); return NextResponse.json({ error: "Download failed." }, { status: 500 }); }
}
