import { NextResponse } from "next/server";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { generateImages } from "@/lib/generate";
import { safetyCheck, STYLES, ASPECTS } from "@/lib/data";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

export async function POST(req: Request) {
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request body." }, { status: 400 }); }
  const prompt = (body.prompt || "").trim();
  const style = body.style || "photorealistic";
  const aspectRatio = body.aspectRatio || "1:1";
  const count = Math.min(4, Math.max(1, parseInt(body.count || "1", 10) || 1));
  const referenceImage = body.referenceImage || null;

  if (!prompt || prompt.length < 3) return NextResponse.json({ error: "Please enter a prompt describing your image (at least 3 characters)." }, { status: 400 });
  if (prompt.length > 2000) return NextResponse.json({ error: "Prompt is too long. Please keep it under 2000 characters." }, { status: 400 });
  if (!STYLES.some(s => s.id === style)) return NextResponse.json({ error: "Invalid style selected." }, { status: 400 });
  if (!ASPECTS.some(a => a.id === aspectRatio)) return NextResponse.json({ error: "Invalid aspect ratio." }, { status: 400 });
  if (referenceImage && (typeof referenceImage !== "string" || !referenceImage.startsWith("data:image/") || referenceImage.length > 7_000_000)) {
    return NextResponse.json({ error: "Reference image must be an image file under 5MB." }, { status: 400 });
  }
  const safety = safetyCheck(prompt);
  if (safety) return NextResponse.json({ error: safety }, { status: 400 });

  const session = await getSessionUser().catch(() => null);
  const seed = Math.floor(Math.random() * 999999);

  // Create record as processing
  let record: any = null;
  try {
    const [r] = await db.insert(generations).values({ userId: session?.userId || null, prompt, style, aspectRatio, imageCount: count, seed, status: "processing", referenceImage: referenceImage ? referenceImage.slice(0, 200000) : null }).returning();
    record = r;
  } catch (e) { console.error("DB insert failed", e); }

  try {
    const result = await generateImages({ prompt, style, aspectRatio, count, seed, referenceImage });
    if (record) {
      await db.update(generations).set({ status: "completed", images: result.images, enhancedPrompt: result.enhancedPrompt, model: result.model }).where(eq(generations.id, record.id));
    }
    return NextResponse.json({ id: record?.id || null, images: result.images, enhancedPrompt: result.enhancedPrompt, model: result.model, seed, status: "completed" });
  } catch (e: any) {
    console.error("Generation failed", e);
    const message = e?.message || "Image generation failed. Please try again.";
    if (record) { try { await db.update(generations).set({ status: "failed", error: message }).where(eq(generations.id, record.id)); } catch {} }
    return NextResponse.json({ error: message, status: "failed", id: record?.id || null }, { status: 502 });
  }
}
