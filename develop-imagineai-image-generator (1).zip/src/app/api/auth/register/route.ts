import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, setSessionCookie } from "@/lib/auth";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  try {
    const { name, email, password } = await req.json();
    if (!name?.trim() || !email?.trim() || !password) return NextResponse.json({ error: "Name, email and password are required." }, { status: 400 });
    if (password.length < 6) return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });
    const normalized = email.trim().toLowerCase();
    const existing = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
    if (existing.length) return NextResponse.json({ error: "An account with this email already exists. Try logging in." }, { status: 409 });
    const [user] = await db.insert(users).values({ name: name.trim(), email: normalized, passwordHash: hashPassword(password) }).returning();
    await setSessionCookie(user.id, user.email);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email } }, { status: 201 });
  } catch (e) { console.error(e); return NextResponse.json({ error: "Registration failed. Please try again." }, { status: 500 }); }
}
