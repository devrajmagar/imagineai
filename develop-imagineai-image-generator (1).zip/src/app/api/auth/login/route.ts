import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword, setSessionCookie } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();
    if (!email?.trim() || !password) return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.email, email.trim().toLowerCase())).limit(1);
    if (!user || !verifyPassword(password, user.passwordHash)) return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    await setSessionCookie(user.id, user.email);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (e) { console.error(e); return NextResponse.json({ error: "Login failed. Please try again." }, { status: 500 }); }
}
