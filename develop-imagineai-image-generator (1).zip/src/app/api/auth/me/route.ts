import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const session = await getSessionUser();
  if (!session) return NextResponse.json({ user: null });
  const [user] = await db.select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt }).from(users).where(eq(users.id, session.userId)).limit(1);
  if (!user) return NextResponse.json({ user: null });
  return NextResponse.json({ user });
}
