import { NextResponse } from "next/server";
import { db } from "@/db";
import { generations, favorites } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { eq, desc, and } from "drizzle-orm";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const mine = url.searchParams.get("mine") === "1";
  const favOnly = url.searchParams.get("favorites") === "1";
  const session = await getSessionUser().catch(() => null);
  try {
    let rows: any[] = [];
    if (mine && session) {
      rows = await db.select().from(generations).where(eq(generations.userId, session.userId)).orderBy(desc(generations.createdAt)).limit(100);
    } else if (favOnly && session) {
      const favs = await db.select({ generationId: favorites.generationId }).from(favorites).where(eq(favorites.userId, session.userId));
      const ids = favs.map(f => f.generationId);
      const all = await db.select().from(generations).orderBy(desc(generations.createdAt)).limit(200);
      rows = all.filter(r => ids.includes(r.id));
    } else {
      rows = await db.select().from(generations).where(eq(generations.status, "completed")).orderBy(desc(generations.createdAt)).limit(60);
    }
    // attach favorite flag for logged in user
    let favSet = new Set<string>();
    if (session) {
      const favs = await db.select({ generationId: favorites.generationId }).from(favorites).where(eq(favorites.userId, session.userId));
      favSet = new Set(favs.map(f => f.generationId));
    }
    const data = rows.map(r => ({ ...r, isFavorite: favSet.has(r.id), createdAt: r.createdAt }));
    return NextResponse.json({ generations: data, user: session });
  } catch (e) { console.error(e); return NextResponse.json({ generations: [], error: "Failed to load gallery." }); }
}

export async function DELETE(req: Request) {
  const session = await getSessionUser().catch(() => null);
  if (!session) return NextResponse.json({ error: "Login required." }, { status: 401 });
  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  const [row] = await db.select().from(generations).where(and(eq(generations.id, id), eq(generations.userId, session.userId))).limit(1);
  if (!row) return NextResponse.json({ error: "Not found." }, { status: 404 });
  await db.delete(generations).where(eq(generations.id, id));
  return NextResponse.json({ ok: true });
}
