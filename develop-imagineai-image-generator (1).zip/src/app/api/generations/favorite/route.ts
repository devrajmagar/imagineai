import { NextResponse } from "next/server";
import { db } from "@/db";
import { favorites } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { eq, and } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const session = await getSessionUser().catch(() => null);
  if (!session) return NextResponse.json({ error: "Login required to save favorites." }, { status: 401 });
  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  const existing = await db.select().from(favorites).where(and(eq(favorites.userId, session.userId), eq(favorites.generationId, id))).limit(1);
  if (existing.length) {
    await db.delete(favorites).where(and(eq(favorites.userId, session.userId), eq(favorites.generationId, id)));
    return NextResponse.json({ isFavorite: false });
  }
  await db.insert(favorites).values({ userId: session.userId, generationId: id });
  return NextResponse.json({ isFavorite: true });
}
