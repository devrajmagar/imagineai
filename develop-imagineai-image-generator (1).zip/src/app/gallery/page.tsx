"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Images, Search, Heart, Wand2, Loader2, Lock } from "lucide-react";
import ImageCard, { type GenItem } from "@/components/ImageCard";
import { STYLES } from "@/lib/data";

export default function GalleryPage() {
  const [items, setItems] = useState<GenItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [tab, setTab] = useState<"mine" | "community" | "favorites">("mine");
  const [search, setSearch] = useState("");
  const [styleFilter, setStyleFilter] = useState("all");

  const load = (t: string) => {
    setLoading(true);
    const url = t === "mine" ? "/api/generations?mine=1" : t === "favorites" ? "/api/generations?favorites=1" : "/api/generations";
    fetch(url).then(r => r.json()).then(d => { setItems(d.generations || []); setUser(d.user); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(tab); }, [tab]);

  const filtered = items.filter(i => (styleFilter === "all" || i.style === styleFilter) && i.prompt.toLowerCase().includes(search.toLowerCase()));
  const needLogin = tab !== "community" && !user && !loading;

  return (
    <div className="pt-16 min-h-screen">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <p className="text-xs font-bold tracking-widest text-fuchsia-400 uppercase flex items-center gap-1.5"><Images className="w-4 h-4" /> Personal gallery</p>
        <h1 className="text-3xl sm:text-4xl font-black mt-1" style={{fontFamily:"Space Grotesk, sans-serif"}}>Your Creations</h1>
        <p className="text-zinc-400 text-sm mt-1">Every generation is saved here. Download, favorite, remix or delete anytime.</p>

        <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:items-center">
          <div className="flex gap-1 p-1 rounded-full glass w-fit">
            {(["mine", "community", "favorites"] as const).map(t => (
              <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-full text-sm font-semibold capitalize transition ${tab === t ? "bg-gradient-to-r from-violet-600 to-fuchsia-500" : "text-zinc-400 hover:text-white"}`}>{t === "mine" ? "My Images" : t === "favorites" ? "❤️ Favorites" : "Community"}</button>
            ))}
          </div>
          <div className="relative flex-1 sm:max-w-xs sm:ml-auto">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search prompts…" className="w-full pl-10 pr-4 py-2.5 rounded-full bg-white/5 border border-white/10 outline-none focus:border-violet-400/60 text-sm" />
          </div>
          <select value={styleFilter} onChange={e => setStyleFilter(e.target.value)} className="px-4 py-2.5 rounded-full bg-white/5 border border-white/10 text-sm outline-none">
            <option value="all" className="bg-zinc-900">All styles</option>
            {STYLES.map(s => <option key={s.id} value={s.id} className="bg-zinc-900">{s.label}</option>)}
          </select>
        </div>

        {loading ? <div className="py-20 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-violet-400" /><p className="text-zinc-500 text-sm mt-3">Loading gallery…</p></div>
        : needLogin ? (
          <div className="mt-8 glass rounded-[28px] p-10 text-center">
            <Lock className="w-10 h-10 mx-auto text-violet-400" />
            <p className="font-bold text-xl mt-4">Log in to see your personal gallery</p>
            <p className="text-zinc-400 text-sm mt-1">Create a free account to save generations, favorites and history across devices.</p>
            <div className="mt-5 flex justify-center gap-3"><Link href="/login" className="px-5 py-2.5 rounded-xl bg-white/10 font-semibold text-sm">Log in</Link><Link href="/register" className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 font-semibold text-sm">Create free account</Link></div>
            <button onClick={() => setTab("community")} className="mt-4 text-sm text-violet-300 hover:text-violet-200">Browse community instead →</button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-8 glass rounded-[28px] p-10 text-center">
            <Images className="w-10 h-10 mx-auto text-zinc-600" />
            <p className="font-bold text-lg mt-4">No images here yet</p>
            <p className="text-zinc-500 text-sm mt-1">{tab === "favorites" ? "Tap the heart on any creation to save it here." : "Generate your first image and it will appear here."}</p>
            <Link href="/generate" className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 font-semibold text-sm"><Wand2 className="w-4 h-4" /> Generate an image</Link>
          </div>
        ) : (
          <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(item => <ImageCard key={item.id} item={item} onDelete={tab === "mine" ? (id) => { fetch("/api/generations", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) }).then(() => setItems(prev => prev.filter(p => p.id !== id))); } : undefined} onToggleFav={() => {}} />)}
          </div>
        )}
        <p className="text-center text-xs text-zinc-600 mt-8 flex items-center justify-center gap-1"><Heart className="w-3 h-3" /> {filtered.length} creations · Saved securely in your account</p>
      </div>
    </div>
  );
}
