"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Sparkles, Wand2, ArrowRight, Zap, ShieldCheck, Download, MousePointerClick, Star, TrendingUp, ChevronRight } from "lucide-react";
import { STYLES, SUGGESTIONS, INSPIRATION } from "@/lib/data";

export default function Home() {
  const router = useRouter();
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("photorealistic");
  const go = (p?: string, s?: string) => {
    const params = new URLSearchParams();
    if (p || prompt) params.set("prompt", p || prompt);
    if (s || style) params.set("style", s || style);
    router.push(`/generate?${params.toString()}`);
  };
  return (
    <div className="pt-16">
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-14 pb-10 sm:pt-20 sm:pb-16 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-medium text-zinc-300 animate-fadeUp">
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> Powered by FLUX AI · Free to start · No credit card
          </div>
          <h1 className="mt-6 text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.02] animate-fadeUp" style={{ fontFamily: "Space Grotesk, sans-serif" }}>
            Turn Your Imagination<br /><span className="text-gradient">Into Reality.</span>
          </h1>
          <p className="mt-5 max-w-2xl mx-auto text-base sm:text-lg text-zinc-400 leading-relaxed animate-fadeUp">
            Describe anything — a portrait, a fantasy world, a luxury product — and ImagineAI creates a stunning, high-resolution image in seconds.
          </p>

          {/* Prompt box */}
          <div className="mt-8 max-w-3xl mx-auto glass rounded-[28px] p-3 sm:p-4 text-left shadow-2xl shadow-violet-900/20 animate-fadeUp">
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe the image you want to create..." rows={3}
              className="w-full bg-transparent resize-none outline-none text-base sm:text-lg placeholder:text-zinc-500 px-3 pt-2" />
            <div className="flex flex-wrap items-center gap-2 mt-2 px-1">
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar max-w-full py-1">
                {STYLES.slice(0, 6).map(s => (
                  <button key={s.id} onClick={() => setStyle(s.id)} className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition ${style === s.id ? "bg-gradient-to-r from-violet-600 to-fuchsia-500 border-transparent text-white" : "bg-white/5 border-white/10 text-zinc-400 hover:text-white"}`}>{s.emoji} {s.label}</button>
                ))}
              </div>
              <button onClick={() => go()} className="ml-auto shrink-0 inline-flex items-center gap-2 px-5 sm:px-6 py-3 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 font-bold text-sm sm:text-base shadow-lg shadow-fuchsia-500/30 hover:scale-[1.02] active:scale-95 transition animate-pulseGlow">
                <Wand2 className="w-5 h-5" /> Generate Image <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap justify-center gap-2 max-w-3xl mx-auto">
            {SUGGESTIONS.slice(0, 4).map(s => (
              <button key={s} onClick={() => go(s)} className="text-xs px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:border-violet-400/40 transition line-clamp-1 max-w-[260px] truncate">{s}</button>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-6 sm:gap-10 text-center">
            {[["2M+", "Images created"], ["12", "Art styles"], ["4K", "Max resolution"], ["< 30s", "Avg. generation"]].map(([n, l]) => (
              <div key={l}><p className="text-2xl font-black text-gradient">{n}</p><p className="text-xs text-zinc-500 mt-0.5">{l}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* SHOWCASE */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
        <div className="flex items-end justify-between gap-4">
          <div><p className="text-xs font-bold tracking-widest text-fuchsia-400 uppercase flex items-center gap-1.5"><TrendingUp className="w-4 h-4" /> Trending now</p><h2 className="text-3xl sm:text-4xl font-black mt-2" style={{fontFamily:"Space Grotesk, sans-serif"}}>Created by the community</h2></div>
          <Link href="/explore" className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-violet-300 hover:text-violet-200">Explore all <ChevronRight className="w-4 h-4" /></Link>
        </div>
        <div className="mt-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {INSPIRATION.slice(0, 8).map((it, i) => (
            <button key={i} onClick={() => go(it.prompt, it.style)} className="group relative rounded-3xl overflow-hidden text-left aspect-[4/5] bg-zinc-900">
              <img src={it.img} alt={it.title} loading="lazy" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-4">
                <p className="font-bold text-sm sm:text-base">{it.title}</p>
                <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">{it.prompt}</p>
                <p className="text-[11px] text-zinc-500 mt-1.5 flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {it.likes} · Tap to remix</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* STYLES */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
        <p className="text-xs font-bold tracking-widest text-cyan-400 uppercase">Popular styles</p>
        <h2 className="text-3xl sm:text-4xl font-black mt-2" style={{fontFamily:"Space Grotesk, sans-serif"}}>One prompt, every style</h2>
        <p className="text-zinc-400 mt-2 max-w-xl">From photorealistic portraits to anime and cyberpunk — pick a style and let the AI do the rest.</p>
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {STYLES.map(s => (
            <button key={s.id} onClick={() => go("", s.id)} className="group glass rounded-3xl p-5 text-left hover:border-white/25 hover:-translate-y-0.5 transition">
              <span className={`inline-grid place-items-center w-11 h-11 rounded-2xl bg-gradient-to-br ${s.gradient} text-xl shadow-lg`}>{s.emoji}</span>
              <p className="font-bold mt-3">{s.label}</p><p className="text-xs text-zinc-500 mt-0.5">{s.desc}</p>
              <p className="text-xs font-semibold text-violet-300 mt-3 inline-flex items-center gap-1 group-hover:gap-2 transition-all">Try this style <ArrowRight className="w-3.5 h-3.5" /></p>
            </button>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
        <div className="glass rounded-[32px] p-6 sm:p-10 relative overflow-hidden">
          <div className="absolute -top-20 right-0 w-72 h-72 bg-fuchsia-600/20 blur-[80px] rounded-full pointer-events-none" />
          <p className="text-xs font-bold tracking-widest text-violet-400 uppercase">How it works</p>
          <h2 className="text-3xl sm:text-4xl font-black mt-2" style={{fontFamily:"Space Grotesk, sans-serif"}}>From words to wow in 3 steps</h2>
          <div className="mt-8 grid sm:grid-cols-3 gap-4">
            {[
              { icon: MousePointerClick, title: "1. Describe it", desc: "Type a short or detailed prompt in natural language. Add a reference image if you want image-to-image." },
              { icon: Wand2, title: "2. Pick a style", desc: "Choose photorealistic, cinematic, anime, fantasy, 3D and more — plus aspect ratio and image count." },
              { icon: Download, title: "3. Download & share", desc: "Get high-resolution images in seconds. Save to your gallery, favorite them, or remix anytime." },
            ].map(s => (
              <div key={s.title} className="rounded-3xl bg-white/[0.03] border border-white/10 p-6">
                <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-500 grid place-items-center"><s.icon className="w-5 h-5" /></span>
                <p className="font-bold text-lg mt-4">{s.title}</p><p className="text-sm text-zinc-400 mt-1.5 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3 text-xs text-zinc-400">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10"><Zap className="w-3.5 h-3.5 text-amber-400" /> Fast generation</span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Safe & moderated prompts</span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10"><Download className="w-3.5 h-3.5 text-cyan-400" /> Full-resolution downloads</span>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-10 pb-16">
        <div className="rounded-[32px] bg-gradient-to-br from-violet-700 via-fuchsia-600 to-pink-600 p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20" style={{backgroundImage:"radial-gradient(circle at 20% 20%, white 1px, transparent 1px)", backgroundSize:"24px 24px"}} />
          <h2 className="relative text-3xl sm:text-5xl font-black" style={{fontFamily:"Space Grotesk, sans-serif"}}>Your next masterpiece is<br />one prompt away.</h2>
          <p className="relative mt-3 text-white/80 max-w-lg mx-auto">Join thousands of creators turning imagination into reality with ImagineAI.</p>
          <div className="relative mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/generate" className="px-7 py-3.5 rounded-2xl bg-white text-zinc-900 font-bold hover:scale-[1.03] transition inline-flex items-center gap-2"><Wand2 className="w-5 h-5" /> Start Creating — Free</Link>
            <Link href="/explore" className="px-7 py-3.5 rounded-2xl bg-black/25 border border-white/30 font-bold hover:bg-black/40 transition">Browse Inspiration</Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-zinc-500">
          <p className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-fuchsia-400" /> <span><b className="text-zinc-300">ImagineAI</b> — Turn Your Imagination Into Reality.</span></p>
          <p>Generate · Explore · Gallery · Dashboard</p>
        </div>
      </footer>
    </div>
  );
}
