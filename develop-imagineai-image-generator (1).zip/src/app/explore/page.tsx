"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { LayoutGrid, Star, Wand2, Search } from "lucide-react";
import { INSPIRATION, STYLES } from "@/lib/data";

export default function ExplorePage() {
  const router = useRouter();
  const [cat, setCat] = useState("all");
  const [search, setSearch] = useState("");
  const filtered = INSPIRATION.filter(i => (cat === "all" || i.style === cat) && (i.title + i.prompt).toLowerCase().includes(search.toLowerCase()));
  const remix = (it: any) => router.push(`/generate?prompt=${encodeURIComponent(it.prompt)}&style=${it.style}`);
  return (
    <div className="pt-16 min-h-screen">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <p className="text-xs font-bold tracking-widest text-cyan-400 uppercase flex items-center gap-1.5"><LayoutGrid className="w-4 h-4" /> Inspiration gallery</p>
        <h1 className="text-3xl sm:text-4xl font-black mt-1" style={{fontFamily:"Space Grotesk, sans-serif"}}>Explore & Remix</h1>
        <p className="text-zinc-400 text-sm mt-1">Tap any creation to use its prompt as a starting point in the studio.</p>
        <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:items-center">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
            <button onClick={() => setCat("all")} className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold border transition ${cat === "all" ? "bg-gradient-to-r from-violet-600 to-fuchsia-500 border-transparent" : "bg-white/5 border-white/10 text-zinc-400 hover:text-white"}`}>All</button>
            {STYLES.map(s => <button key={s.id} onClick={() => setCat(s.id)} className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold border transition ${cat === s.id ? "bg-gradient-to-r from-violet-600 to-fuchsia-500 border-transparent" : "bg-white/5 border-white/10 text-zinc-400 hover:text-white"}`}>{s.emoji} {s.label}</button>)}
          </div>
          <div className="relative sm:ml-auto sm:w-64 shrink-0">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search inspiration…" className="w-full pl-10 pr-4 py-2.5 rounded-full bg-white/5 border border-white/10 outline-none focus:border-violet-400/60 text-sm" />
          </div>
        </div>
        <div className="mt-6 columns-2 md:columns-3 lg:columns-4 gap-4 [column-fill:_balance]">
          {filtered.map((it, i) => (
            <button key={i} onClick={() => remix(it)} className="group relative w-full rounded-3xl overflow-hidden mb-4 break-inside-avoid bg-zinc-900 text-left">
              <img src={it.img} alt={it.title} loading="lazy" className={`w-full object-cover group-hover:scale-105 transition duration-700 ${i % 3 === 0 ? "aspect-[3/4]" : i % 3 === 1 ? "aspect-square" : "aspect-[4/3]"}`} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-4">
                <p className="font-bold">{it.title}</p>
                <p className="text-xs text-zinc-400 line-clamp-2 mt-0.5">{it.prompt}</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[11px] text-zinc-400 flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {it.likes}</span>
                  <span className="text-[11px] font-bold text-violet-300 inline-flex items-center gap-1 opacity-0 group-hover:opacity-100 transition"><Wand2 className="w-3 h-3" /> Remix</span>
                </div>
              </div>
            </button>
          ))}
        </div>
        {filtered.length === 0 && <p className="text-center text-zinc-500 py-16">No inspiration matches your search.</p>}
      </div>
    </div>
  );
}
