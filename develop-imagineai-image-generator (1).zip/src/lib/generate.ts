import { ASPECTS, enhancePrompt } from "./data";

export async function generateImages(opts: { prompt: string; style: string; aspectRatio: string; count: number; seed: number; referenceImage?: string | null }) {
  const enhanced = enhancePrompt(opts.prompt, opts.style);
  const aspect = ASPECTS.find(a => a.id === opts.aspectRatio) || ASPECTS[0];
  const width = aspect.w, height = aspect.h;

  // Provider 1: OpenAI if key configured (server-side only)
  const openaiKey = process.env.OPENAI_API_KEY;
  if (openaiKey) {
    const sizeMap: Record<string, string> = { "1:1": "1024x1024", "16:9": "1792x1024", "9:16": "1024x1792", "4:5": "1024x1024", "3:2": "1792x1024", "2:3": "1024x1792" };
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${openaiKey}` },
      body: JSON.stringify({ model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1", prompt: enhanced, n: opts.count, size: sizeMap[opts.aspectRatio] || "1024x1024" }),
      signal: AbortSignal.timeout(120000),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`OpenAI generation failed (${res.status}): ${txt.slice(0, 300)}`);
    }
    const json = await res.json();
    const images: string[] = (json.data || []).map((d: any) => d.b64_json ? `data:image/png;base64,${d.b64_json}` : d.url).filter(Boolean);
    if (!images.length) throw new Error("OpenAI returned no images. Generation failed — please try again.");
    return { images, enhancedPrompt: enhanced, model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1 (OpenAI)" };
  }

  // Provider 2: Pollinations FLUX (free, no key required) — real AI generation
  const baseSeed = opts.seed;
  const urls = Array.from({ length: opts.count }, (_, i) => {
    const seed = baseSeed + i * 137;
    const q = new URLSearchParams({ width: String(width), height: String(height), seed: String(seed), model: "flux", enhance: "true", nologo: "true", safe: "true", private: "true" });
    // Reference image: append hint to prompt (img2img-style guidance)
    const finalPrompt = opts.referenceImage ? `${enhanced}, inspired by reference image composition and colors` : enhanced;
    return `https://image.pollinations.ai/prompt/${encodeURIComponent(finalPrompt)}?${q.toString()}`;
  });

  // Verify each image actually generates (never pretend success)
  const verified: string[] = [];
  await Promise.all(urls.map(async (url) => {
    let lastErr: unknown = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await fetch(url, { signal: AbortSignal.timeout(90000), headers: { Accept: "image/*" } });
        if (!res.ok) throw new Error(`Image service returned ${res.status}`);
        const ct = res.headers.get("content-type") || "";
        if (!ct.startsWith("image/")) throw new Error(`Image service returned non-image (${ct})`);
        const buf = await res.arrayBuffer();
        if (buf.byteLength < 4000) throw new Error("Generated image is empty or too small");
        verified.push(url);
        return;
      } catch (e) { lastErr = e; }
    }
    throw lastErr instanceof Error ? lastErr : new Error("Image generation failed. Please try again.");
  }));

  if (!verified.length) throw new Error("No images were generated. Please try again.");
  // Keep order stable-ish by sorting by seed order in urls
  const ordered = urls.filter(u => verified.includes(u));
  return { images: ordered, enhancedPrompt: enhanced, model: "FLUX via Pollinations" };
}
