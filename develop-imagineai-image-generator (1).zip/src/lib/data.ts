export type StyleDef = { id: string; label: string; emoji: string; desc: string; suffix: string; gradient: string };

export const STYLES: StyleDef[] = [
  { id: "photorealistic", label: "Photorealistic", emoji: "📸", desc: "Ultra-real, 8K detail", suffix: "photorealistic, ultra detailed, 8k, sharp focus, professional photography, natural lighting, high resolution", gradient: "from-violet-600 to-fuchsia-500" },
  { id: "cinematic", label: "Cinematic", emoji: "🎬", desc: "Film still, dramatic light", suffix: "cinematic film still, dramatic lighting, anamorphic lens, film grain, moody color grading, 35mm, epic composition", gradient: "from-amber-500 to-rose-600" },
  { id: "3d-render", label: "3D Render", emoji: "🧊", desc: "Pixar-style 3D", suffix: "3d render, octane render, pixar style, volumetric lighting, ultra detailed, studio lighting, 8k", gradient: "from-cyan-500 to-blue-600" },
  { id: "anime", label: "Anime", emoji: "🌸", desc: "Studio Ghibli vibe", suffix: "anime illustration, studio ghibli style, vibrant colors, cel shading, detailed background, beautiful line art", gradient: "from-pink-500 to-orange-400" },
  { id: "fantasy", label: "Fantasy", emoji: "🐉", desc: "Magic & mythical", suffix: "epic fantasy art, magical atmosphere, ethereal lighting, intricate details, digital painting, concept art", gradient: "from-emerald-500 to-teal-600" },
  { id: "portrait", label: "Portrait", emoji: "👤", desc: "Studio portrait", suffix: "professional portrait photography, shallow depth of field, studio lighting, expressive, high detail skin texture", gradient: "from-indigo-500 to-violet-600" },
  { id: "fashion", label: "Fashion", emoji: "👗", desc: "Editorial luxury", suffix: "high fashion editorial, luxury magazine style, elegant, vogue photography, dramatic pose, designer clothing", gradient: "from-rose-500 to-pink-600" },
  { id: "luxury", label: "Luxury", emoji: "💎", desc: "Gold, premium, rich", suffix: "luxury aesthetic, gold accents, premium materials, elegant, rich colors, high-end product photography, opulent", gradient: "from-yellow-500 to-amber-600" },
  { id: "nature", label: "Nature", emoji: "🌿", desc: "Wild & serene", suffix: "stunning nature photography, golden hour, vibrant colors, national geographic style, ultra detailed landscape", gradient: "from-green-500 to-emerald-600" },
  { id: "architecture", label: "Architecture", emoji: "🏛️", desc: "Futuristic buildings", suffix: "architectural photography, futuristic design, dramatic perspective, clean lines, golden hour lighting, ultra detailed", gradient: "from-slate-500 to-zinc-700" },
  { id: "artistic", label: "Artistic", emoji: "🎨", desc: "Painterly & abstract", suffix: "fine art painting, expressive brushstrokes, oil on canvas, vibrant, masterpiece, artistic composition", gradient: "from-purple-500 to-indigo-600" },
  { id: "cyberpunk", label: "Cyberpunk", emoji: "🤖", desc: "Neon future", suffix: "cyberpunk aesthetic, neon lights, futuristic, rain reflections, blade runner style, high contrast, dramatic", gradient: "from-fuchsia-600 to-cyan-500" },
];

export const ASPECTS = [
  { id: "1:1", label: "1:1", desc: "Square", w: 1024, h: 1024, css: "aspect-square" },
  { id: "16:9", label: "16:9", desc: "Landscape", w: 1344, h: 768, css: "aspect-video" },
  { id: "9:16", label: "9:16", desc: "Portrait", w: 768, h: 1344, css: "aspect-[9/16]" },
  { id: "4:5", label: "4:5", desc: "Social", w: 1024, h: 1280, css: "aspect-[4/5]" },
  { id: "3:2", label: "3:2", desc: "Photo", w: 1216, h: 832, css: "aspect-[3/2]" },
  { id: "2:3", label: "2:3", desc: "Poster", w: 832, h: 1216, css: "aspect-[2/3]" },
];

export const SUGGESTIONS = [
  "A majestic lion wearing a golden crown in a royal palace, cinematic lighting",
  "Futuristic Tokyo street at night with neon signs and rain reflections",
  "A cozy cottage in a magical forest with glowing mushrooms and fireflies",
  "Astronaut discovering a glowing alien flower on Mars, photorealistic",
  "Luxury sports car in a dark studio with dramatic spotlight",
  "Anime girl with cherry blossoms, Studio Ghibli style, dreamy sky",
  "Ancient dragon flying over misty mountains at sunset, epic fantasy",
  "Minimalist modern house with infinity pool overlooking ocean at golden hour",
  "Cyberpunk portrait of a woman with neon hair and futuristic eyewear",
  "A vintage camera on a wooden desk with warm window light, still life",
  "Underwater city with mermaids and glowing jellyfish, magical",
  "Portrait of an elderly sailor with weathered face, dramatic lighting",
];

export const INSPIRATION = [
  { img: "https://images.pexels.com/photos/8108427/pexels-photo-8108427.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Cyberpunk man portrait with neon lighting, futuristic city background, cinematic", style: "cyberpunk", title: "Neon Portrait", likes: "12.4k" },
  { img: "https://images.pexels.com/photos/10109585/pexels-photo-10109585.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Surreal 3D landscape with vibrant mountains and sea, digital render", style: "3d-render", title: "Dream Mountains", likes: "9.1k" },
  { img: "https://images.pexels.com/photos/36551319/pexels-photo-36551319.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Majestic rocky mountains under vibrant purple twilight sky", style: "nature", title: "Purple Twilight", likes: "8.7k" },
  { img: "https://images.pexels.com/photos/8107826/pexels-photo-8107826.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Cyberpunk fashion portrait, woman with futuristic eyewear and neon light", style: "fashion", title: "Future Fashion", likes: "11.2k" },
  { img: "https://images.pexels.com/photos/20599145/pexels-photo-20599145.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Fashionable woman posing under neon lights, chic dress, glamorous", style: "fashion", title: "Neon Glamour", likes: "7.9k" },
  { img: "https://images.pexels.com/photos/8107956/pexels-photo-8107956.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Stylish woman in futuristic attire, cyberpunk environment, neon", style: "cyberpunk", title: "Cyber Muse", likes: "10.5k" },
  { img: "https://images.pexels.com/photos/33800716/pexels-photo-33800716.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Misty mountains at sunrise with dramatic clouds, serene nature", style: "nature", title: "Misty Sunrise", likes: "6.8k" },
  { img: "https://images.pexels.com/photos/36590316/pexels-photo-36590316.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Luxurious chandelier in modern stylish interior, architectural elegance", style: "luxury", title: "Luxury Interior", likes: "5.4k" },
  { img: "https://images.pexels.com/photos/30993861/pexels-photo-30993861.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Elegant woman in white fur coat on modern staircase, urban fashion", style: "fashion", title: "White Elegance", likes: "9.8k" },
  { img: "https://images.pexels.com/photos/34640431/pexels-photo-34640431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Dreamy mountain sunset with bokeh lights, magical atmosphere", style: "fantasy", title: "Dreamy Sunset", likes: "7.3k" },
  { img: "https://images.pexels.com/photos/40627854/pexels-photo-40627854.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Mysterious woman in forest holding sword, medieval fantasy", style: "fantasy", title: "Forest Warrior", likes: "8.1k" },
  { img: "https://images.pexels.com/photos/18076559/pexels-photo-18076559.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", prompt: "Person in futuristic mask under vibrant neon lighting, cyberpunk", style: "cyberpunk", title: "Neon Mask", likes: "6.2k" },
];

export function enhancePrompt(prompt: string, styleId: string) {
  const style = STYLES.find(s => s.id === styleId) || STYLES[0];
  const clean = prompt.trim().replace(/\s+/g, " ");
  return `${clean}, ${style.suffix}, masterpiece, best quality`;
}

const BLOCKED = ["child sexual", "minor sexual", "nude minor", "sexual minor", "porn", "explicit sexual", "bestiality", "non-consensual"];
export function safetyCheck(prompt: string): string | null {
  const lower = prompt.toLowerCase();
  for (const b of BLOCKED) if (lower.includes(b)) return "This prompt violates our safety guidelines. Please try a different creative description.";
  if (/(^|\b)(kill|murder|suicide|self-harm)(\b|$)/.test(lower)) return "This prompt may violate safety guidelines. Please rephrase your request.";
  return null;
}
