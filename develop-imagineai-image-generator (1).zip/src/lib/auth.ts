import crypto from "crypto";
import { cookies } from "next/headers";

const SECRET = process.env.AUTH_SECRET || process.env.DATABASE_URL || "imagineai-dev-secret-change-in-prod";

export function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
export function verifyPassword(password: string, stored: string) {
  try {
    const [salt, hash] = stored.split(":");
    const candidate = crypto.scryptSync(password, salt, 64).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(candidate));
  } catch { return false; }
}
export function signToken(userId: string, email: string) {
  const payload = Buffer.from(JSON.stringify({ userId, email, exp: Date.now() + 1000 * 60 * 60 * 24 * 7 })).toString("base64url");
  const sig = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
export function verifyToken(token: string): { userId: string; email: string } | null {
  try {
    const [payload, sig] = token.split(".");
    const expected = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (data.exp < Date.now()) return null;
    return { userId: data.userId, email: data.email };
  } catch { return null; }
}
export async function getSessionUser() {
  const store = await cookies();
  const token = store.get("imagineai_token")?.value;
  if (!token) return null;
  return verifyToken(token);
}
export async function setSessionCookie(userId: string, email: string) {
  const store = await cookies();
  store.set("imagineai_token", signToken(userId, email), { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7, secure: process.env.NODE_ENV === "production" });
}
export async function clearSessionCookie() {
  const store = await cookies();
  store.delete("imagineai_token");
}
