"use client";
import { useState } from "react";
import { Download, Heart, RefreshCw, X, Copy, Check } from "lucide-react";
import Link from "next/link";

export type GenItem = {
  id: string; prompt: string; enhancedPrompt?: string; style: string; aspectRatio: string; images: string[]; status: string; model?: string; isFavorite?: boolean; createdAt: string; error?: string; referenceImage?: string;
};

export function downloadImage(url: string) {
  if (url.startsWith("data:")) {
    const a = document.createElement("a"); a.href = url; a.download = `imagineai-${Date.now()}.png`; a.click(); return;
  }
  window.open(`/api/download?url=${encodeURIComponent(url)}`, "_blank");
}

export default function ImageCard({ item, onDelete, onToggleFav, compact }: { item: GenItem; onDelete?: (id: string) => void; onToggleFav?: (id: string) => void; compact?: boolean }) {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [fav, setFav] = useState(!!item.isFavorite);
  const images = item.images || [];
  if (item.status === "failed") {
    return (
      <div className="glass rounded-3xl p-5">
        <p className="text-sm font-semibold text-rose-300">Generation failed</p>
        <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{item.prompt}</p>
        <p className="text-xs text-rose-400/80 mt-2">{item.error || "The image service did not return an image."}</p>
        <Link href={`/generate?prompt=${encodeURIComponent(item.prompt)}&style=${item.style}`} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-violet-300 hover:text-violet-200"><RefreshCw className="w-3.5 h-3.5" /> Try again</Link>
      </div>
    );
  }
  return (
    <div className="group glass rounded-3xl overflow-hidden hover:border-white/20 transition">
      <div className={`grid gap-1 ${images.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
        {images.map((src, i) => (
          <button key={i} onClick={() => setLightbox(src)} className="relative overflow-hidden bg-zinc-900">
            <img src={src} alt={item.prompt} loading="lazy" className={`w-full object-cover group-hover:scale-[1.03] transition duration-500 ${compact ? "h-48" : images.length > 1 ? "h-52" : "h-64"}`} />
            <span className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition" />
          </button>
        ))}
      </div>
      <div className="p-4">
        <p className="text-sm text-zinc-200 line-clamp-2 leading-snug">{item.prompt}</p>
        <div className="mt-3 flex items-center gap-2 flex-wrap">
          <span className="text-[11px] px-2 py-1 rounded-full bg-violet-500/15 text-violet-300 border border-violet-500/20 capitalize">{item.style}</span>
          <span className="text-[11px] px-2 py-1 rounded-full bg-white/5 border border-white/10 text-zinc-400">{item.aspectRatio}</span>
          <span className="text-[11px] text-zinc-500">{new Date(item.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
        </div>
        <div className="mt-3 flex items-center gap-1.5">
          {images[0] && <button onClick={() => downloadImage(images[0])} className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 text-xs font-semibold hover:opacity-90"><Download className="w-3.5 h-3.5" /> Download</button>}
          <button onClick={() => { navigator.clipboard.writeText(item.prompt); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10" title="Copy prompt">{copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}</button>
          {onToggleFav && <button onClick={async () => { const r = await fetch("/api/generations/favorite", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id }) }); if (r.ok) { const d = await r.json(); setFav(d.isFavorite); onToggleFav(item.id); } else if (r.status === 401) alert("Please log in to save favorites."); }} className={`p-2 rounded-xl border ${fav ? "bg-rose-500/20 border-rose-500/30 text-rose-400" : "bg-white/5 border-white/10 hover:bg-white/10"}`} title="Favorite"><Heart className={`w-4 h-4 ${fav ? "fill-current" : ""}`} /></button>}
          <Link href={`/generate?prompt=${encodeURIComponent(item.prompt)}&style=${item.style}&aspect=${item.aspectRatio}`} className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10" title="Remix / regenerate"><RefreshCw className="w-4 h-4" /></Link>
          {onDelete && <button onClick={() => { if (confirm("Delete this generation?")) onDelete(item.id); }} className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-rose-500/20 hover:text-rose-300" title="Delete"><X className="w-4 h-4" /></button>}
        </div>
      </div>
      {lightbox && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <img src={lightbox} className="max-h-[90vh] max-w-full rounded-2xl shadow-2xl" alt="preview" />
          <button className="absolute top-5 right-5 p-3 rounded-full bg-white/10 hover:bg-white/20"><X className="w-5 h-5" /></button>
          <button onClick={(e) => { e.stopPropagation(); downloadImage(lightbox); }} className="absolute bottom-6 left-1/2 -translate-x-1/2 px-5 py-2.5 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-500 font-semibold text-sm flex items-center gap-2"><Download className="w-4 h-4" /> Download full size</button>
        </div>
      )}
    </div>
  );
}
