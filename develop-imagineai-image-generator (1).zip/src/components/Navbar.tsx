"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Sparkles, Wand2, LayoutGrid, Images, LayoutDashboard, LogOut, User, Menu, X } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";

export default function Navbar() {
  const [user, setUser] = useState<any>(null);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  useEffect(() => { fetch("/api/auth/me").then(r => r.json()).then(d => setUser(d.user)).catch(() => {}); }, [pathname]);
  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); setUser(null); router.push("/"); router.refresh(); };
  const links = [
    { href: "/", label: "Home", icon: Sparkles },
    { href: "/generate", label: "Generate", icon: Wand2 },
    { href: "/explore", label: "Explore", icon: LayoutGrid },
    { href: "/gallery", label: "Gallery", icon: Images },
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  ];
  return (
    <header className="fixed top-0 inset-x-0 z-50 border-b border-white/10 bg-[#05050a]/80 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2.5 shrink-0">
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 via-fuchsia-500 to-cyan-400 grid place-items-center shadow-lg shadow-fuchsia-500/30"><Sparkles className="w-5 h-5 text-white" /></span>
          <span className="font-bold text-lg tracking-tight" style={{fontFamily:"Space Grotesk, sans-serif"}}>Imagine<span className="text-gradient">AI</span></span>
          <span className="hidden sm:inline text-[10px] px-2 py-0.5 rounded-full bg-white/10 border border-white/10 text-zinc-300">BETA</span>
        </Link>
        <nav className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <Link key={l.href} href={l.href} className={`px-3.5 py-2 rounded-full text-sm font-medium transition ${pathname === l.href ? "bg-white/10 text-white" : "text-zinc-400 hover:text-white hover:bg-white/5"}`}>{l.label}</Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Link href="/dashboard" className="hidden sm:flex items-center gap-2 pl-1 pr-3 py-1 rounded-full glass hover:bg-white/10 transition">
                <span className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 grid place-items-center text-xs font-bold">{user.name?.[0]?.toUpperCase()}</span>
                <span className="text-sm font-medium max-w-[120px] truncate">{user.name}</span>
              </Link>
              <button onClick={logout} className="p-2 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white" title="Logout"><LogOut className="w-4 h-4" /></button>
            </>
          ) : (
            <>
              <Link href="/login" className="hidden sm:block px-4 py-2 text-sm font-medium text-zinc-300 hover:text-white">Log in</Link>
              <Link href="/register" className="px-4 py-2 rounded-full text-sm font-semibold bg-gradient-to-r from-violet-600 to-fuchsia-500 hover:opacity-90 shadow-lg shadow-fuchsia-500/25">Get Started Free</Link>
            </>
          )}
          <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg hover:bg-white/10">{open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}</button>
        </div>
      </div>
      {open && (
        <div className="md:hidden border-t border-white/10 bg-[#05050a] px-4 py-3 space-y-1">
          {links.map(l => <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 text-sm font-medium"><l.icon className="w-4 h-4" />{l.label}</Link>)}
          {!user && <><Link href="/login" onClick={() => setOpen(false)} className="block px-3 py-2.5 text-sm">Log in</Link><Link href="/register" onClick={() => setOpen(false)} className="block px-3 py-2.5 text-sm font-semibold text-fuchsia-300">Create free account</Link></>}
          {user && <button onClick={logout} className="flex items-center gap-3 px-3 py-2.5 text-sm w-full text-left"><LogOut className="w-4 h-4" />Logout</button>}
        </div>
      )}
    </header>
  );
}
